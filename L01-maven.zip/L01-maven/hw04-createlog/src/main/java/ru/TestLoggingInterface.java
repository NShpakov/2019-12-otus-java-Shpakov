package main.java.ru;

public interface TestLoggingInterface {

	void calculation(int param);
}
